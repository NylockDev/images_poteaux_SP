# extractors.py
import re
from datetime import datetime
from config import STUDY_PATTERNS, INSTALLATION_PATTERN, RDV_KEYWORDS
import logging

class DataExtractor:
    def __init__(self):
        self.etudes = []
        self.installations = []
        self.rendezvous = []
        self.doublons = []
    
    def extract_from_file(self, file_path):
        """Extrait toutes les données d'un fichier WhatsApp"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Séparation des messages (format WhatsApp typique)
            messages = self._split_messages(content)
            
            for message in messages:
                self._process_message(message.strip())
            
            return {
                'etudes': self.etudes,
                'installations': self.installations,
                'rendezvous': self.rendezvous,
                'doublons': self.doublons
            }
            
        except Exception as e:
            logging.error(f"Erreur extraction fichier: {e}")
            return None
    
    def _split_messages(self, content):
        """Sépare les messages WhatsApp (format avec date)"""
        # Pattern pour détecter le début des messages WhatsApp
        pattern = r'\d{1,2}/\d{1,2}/\d{2,4},\s*\d{1,2}:\d{2}'
        messages = re.split(pattern, content)
        return [msg for msg in messages if msg.strip()]
    
    def _process_message(self, message):
        """Traite un message et détermine son type"""
        message_lower = message.lower()
        
        # Vérification étude
        if any(keyword in message_lower for keyword in ['étude', 'etude', 'team sti']):
            etude_data = self._extract_etude(message)
            if etude_data and self._is_not_doublon(etude_data, 'etude'):
                self.etudes.append(etude_data)
            elif etude_data:
                self.doublons.append(etude_data)
        
        # Vérification installation
        elif 'nom du client' in message_lower:
            installation_data = self._extract_installation(message)
            if installation_data and self._is_not_doublon(installation_data, 'installation'):
                self.installations.append(installation_data)
            elif installation_data:
                self.doublons.append(installation_data)
        
        # Vérification rendez-vous
        elif any(keyword in message_lower for keyword in RDV_KEYWORDS):
            rdv_data = self._extract_rdv(message)
            if rdv_data:
                self.rendezvous.append(rdv_data)
    
    def _extract_etude(self, message):
        """Extrait les données d'étude selon les 3 templates"""
        for template_name, patterns in STUDY_PATTERNS.items():
            try:
                data = {'template': template_name}
                
                # Extraction des champs
                for field, pattern in patterns.items():
                    match = re.search(pattern, message, re.IGNORECASE | re.DOTALL)
                    if match:
                        data[field] = match.group(1).strip()
                
                # Si on a au moins le nom du client, c'est une étude valide
                if data.get('client'):
                    # Normalisation des noms de champs
                    normalized_data = {
                        'nom_client': data['client'],
                        'tn': data.get('tn', ''),
                        'numero': data.get('numero', ''),
                        'forfait': data.get('forfait', ''),
                        'localisation': data.get('localisation', ''),
                        'materiel': data.get('materiel', ''),
                        'notes': data.get('notes', ''),
                        'date_etude': datetime.now().strftime('%Y-%m-%d')
                    }
                    return normalized_data
                    
            except Exception as e:
                logging.warning(f"Erreur template {template_name}: {e}")
                continue
        
        return None
    
    def _extract_installation(self, message):
        """Extrait les données d'installation"""
        try:
            data = {}
            
            for field, pattern in INSTALLATION_PATTERN.items():
                match = re.search(pattern, message, re.IGNORECASE | re.DOTALL)
                if match:
                    data[field] = match.group(1).strip()
            
            if data.get('nom'):
                # Extraction date d'installation (simplifiée)
                date_match = re.search(r'(\d{1,2}/\d{1,2}/\d{2,4})', message)
                date_installation = date_match.group(1) if date_match else datetime.now().strftime('%Y-%m-%d')
                
                return {
                    'nom_client': data['nom'],
                    'tn': data.get('tn', ''),
                    'numero': data.get('numero', ''),
                    'port': data.get('port', ''),
                    'materiel_utilise': data.get('materiel', ''),
                    'observation': data.get('observation', ''),
                    'date_installation': date_installation
                }
        
        except Exception as e:
            logging.error(f"Erreur extraction installation: {e}")
        
        return None
    
    def _extract_rdv(self, message):
        """Extrait les rendez-vous"""
        try:
            # Recherche du nom du client dans le message
            nom_match = re.search(r'([A-Z][a-z]+ [A-Z][a-z]+)', message)
            nom_client = nom_match.group(1) if nom_match else "Client inconnu"
            
            # Recherche de date
            date_match = re.search(r'(\d{1,2}/\d{1,2}/\d{2,4})', message)
            date_rdv = date_match.group(1) if date_match else None
            
            return {
                'nom_client': nom_client,
                'message_complet': message[:500],  # Limite la longueur
                'date_rdv': date_rdv
            }
        
        except Exception as e:
            logging.error(f"Erreur extraction RDV: {e}")
            return None
    
    def _is_not_doublon(self, data, data_type):
        """Vérifie si les données ne sont pas un doublon"""
        if data_type == 'etude':
            existing_keys = [(e['nom_client'], e.get('tn', ''), e.get('numero', '')) 
                           for e in self.etudes]
            new_key = (data['nom_client'], data.get('tn', ''), data.get('numero', ''))
        else:  # installation
            existing_keys = [(i['nom_client'], i.get('tn', ''), i.get('numero', '')) 
                           for i in self.installations]
            new_key = (data['nom_client'], data.get('tn', ''), data.get('numero', ''))
        
        return new_key not in existing_keys
