# database.py
import sqlite3
import pandas as pd
from datetime import datetime
import logging

class FTTHDatabase:
    def __init__(self, db_path="ftth_data.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialise la structure de la base de données"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Table des études
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS etudes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_client TEXT NOT NULL,
                tn TEXT,
                numero TEXT,
                forfait TEXT,
                localisation TEXT,
                materiel TEXT,
                notes TEXT,
                date_etude DATE,
                date_import TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                unique_key TEXT UNIQUE
            )
        ''')
        
        # Table des installations
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_client TEXT NOT NULL,
                tn TEXT,
                numero TEXT,
                port TEXT,
                materiel_utilise TEXT,
                observation TEXT,
                date_installation DATE,
                date_import TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                unique_key TEXT UNIQUE
            )
        ''')
        
        # Table des rendez-vous
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rendezvous (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_client TEXT NOT NULL,
                message_complet TEXT,
                date_rdv DATE,
                date_import TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def insert_etude(self, data):
        """Insère une étude dans la base"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Création d'une clé unique pour éviter les doublons
        unique_key = f"{data['nom_client']}_{data.get('tn', '')}_{data.get('numero', '')}"
        
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO etudes 
                (nom_client, tn, numero, forfait, localisation, materiel, notes, date_etude, unique_key)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['nom_client'],
                data.get('tn'),
                data.get('numero'),
                data.get('forfait'),
                data.get('localisation'),
                data.get('materiel'),
                data.get('notes'),
                data.get('date_etude'),
                unique_key
            ))
            conn.commit()
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            logging.error(f"Erreur insertion étude: {e}")
            return False
        finally:
            conn.close()
    
    def insert_installation(self, data):
        """Insère une installation dans la base"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        unique_key = f"{data['nom_client']}_{data.get('tn', '')}_{data.get('numero', '')}"
        
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO installations 
                (nom_client, tn, numero, port, materiel_utilise, observation, date_installation, unique_key)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['nom_client'],
                data.get('tn'),
                data.get('numero'),
                data.get('port'),
                data.get('materiel_utilise'),
                data.get('observation'),
                data.get('date_installation'),
                unique_key
            ))
            conn.commit()
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            logging.error(f"Erreur insertion installation: {e}")
            return False
        finally:
            conn.close()
    
    def insert_rdv(self, data):
        """Insère un rendez-vous dans la base"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO rendezvous (nom_client, message_complet, date_rdv)
                VALUES (?, ?, ?)
            ''', (
                data['nom_client'],
                data['message_complet'],
                data.get('date_rdv')
            ))
            conn.commit()
            return True
        except sqlite3.Error as e:
            logging.error(f"Erreur insertion RDV: {e}")
            return False
        finally:
            conn.close()
    
    def get_etudes(self, date_debut=None, date_fin=None):
        """Récupère les études avec filtrage date"""
        conn = sqlite3.connect(self.db_path)
        query = "SELECT * FROM etudes"
        params = []
        
        if date_debut and date_fin:
            query += " WHERE date_import BETWEEN ? AND ?"
            params.extend([date_debut, date_fin])
        
        df = pd.read_sql_query(query, conn, params=params)
        conn.close()
        return df
    
    def get_installations(self, date_debut=None, date_fin=None):
        """Récupère les installations avec filtrage date"""
        conn = sqlite3.connect(self.db_path)
        query = "SELECT * FROM installations"
        params = []
        
        if date_debut and date_fin:
            query += " WHERE date_import BETWEEN ? AND ?"
            params.extend([date_debut, date_fin])
        
        df = pd.read_sql_query(query, conn, params=params)
        conn.close()
        return df
    
    def get_cumul_materiel(self, date_debut, date_fin):
        """Calcule le cumul de matériel sur une période"""
        conn = sqlite3.connect(self.db_path)
        
        # Cumul des études
        etudes_df = pd.read_sql_query('''
            SELECT materiel FROM etudes 
            WHERE date_import BETWEEN ? AND ?
        ''', conn, params=[date_debut, date_fin])
        
        # Cumul des installations
        installations_df = pd.read_sql_query('''
            SELECT materiel_utilise FROM installations 
            WHERE date_import BETWEEN ? AND ?
        ''', conn, params=[date_debut, date_fin])
        
        conn.close()
        
        # Analyse du matériel (implémentation simplifiée)
        cumul = {}
        
        for df, col in [(etudes_df, 'materiel'), (installations_df, 'materiel_utilise')]:
            for materiel in df[col].dropna():
                # Extraction des quantités (ex: "*PTO: 01" -> PTO: 1)
                lines = str(materiel).split('\n')
                for line in lines:
                    if ':' in line and any(char.isdigit() for char in line):
                        parts = line.split(':')
                        if len(parts) >= 2:
                            item = parts[0].replace('*', '').replace('-', '').strip()
                            qty = parts[1].strip()
                            if item and qty.isdigit():
                                cumul[item] = cumul.get(item, 0) + int(qty)
        
        return cumul
