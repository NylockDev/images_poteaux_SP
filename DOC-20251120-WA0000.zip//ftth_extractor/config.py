# config.py
import customtkinter as ctk

# Configuration de l'interface
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# Thème MTN CI (Jaune/Noir)
MTN_COLORS = {
    "primary": "#FFCC00",  # Jaune MTN
    "secondary": "#000000", # Noir
    "accent": "#FFD700",
    "background": "#1a1a1a",
    "text": "#FFFFFF"
}

# Patterns pour l'extraction
STUDY_PATTERNS = {
    "template1": {
        "client": r"Client:\s*(.+)",
        "numero": r"Numéro joignable\s*:\s*(.+)",
        "tn": r"TN:\s*(.+)",
        "forfait": r"Forfait:\s*(.+)",
        "localisation": r"(?:Localisation|Lieu):\s*(.+)",
        "materiel": r"Matériel\s*(.+?)(?=NB:|$)",
        "notes": r"NB:\s*(.+)"
    },
    "template2": {
        "client": r"CLIENT\s*:\s*(.+)",
        "numero": r"NUMERO JOUNABBLE:\s*(.+)",
        "forfait": r"FORFAIT:\s*(.+)",
        "localisation": r"(?:Localisation|Lieu):\s*(.+)",
        "notes": r"NB:\s*(.+)"
    },
    "template3": {
        "client": r"Client\s*:\s*(.+)",
        "numero": r"Numéro joignable:\s*(.+)",
        "tn": r"TN:\s*(.+)",
        "forfait": r"Forfait:\s*(.+)",
        "localisation": r"(?:Localisation|Lieu):\s*(.+)",
        "materiel": r"Matériel\s*(.+?)(?=NB:|$)",
        "notes": r"NB:\s*(.+)"
    }
}

INSTALLATION_PATTERN = {
    "nom": r"Nom du client\s*:\s*(.+)",
    "numero": r"NUMÉRO:\s*(.+)",
    "tn": r"TN:\s*(.+)",
    "port": r"NUMÉRO DU PORT:\s*(.+)",
    "materiel": r"MATÉRIELS UTILISER\s*(.+?)(?=Observation|$)",
    "observation": r"Observation\s*:\s*(.+)"
}

RDV_KEYWORDS = ["rendez-vous", "rdv", "prise de rendez-vous", "rendez vous"]
