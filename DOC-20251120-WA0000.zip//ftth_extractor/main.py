# main.py
from gui import FTTHApp
import logging

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ftth_extraction.log'),
        logging.StreamHandler()
    ]
)

def main():
    """Fonction principale"""
    try:
        app = FTTHApp()
        app.run()
    except Exception as e:
        logging.error(f"Erreur application: {e}")
        raise

if __name__ == "__main__":
    main()
