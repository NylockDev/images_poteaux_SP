# gui.py
import customtkinter as ctk
from tkinter import filedialog, messagebox, scrolledtext
import tkinter as tk
import os
from datetime import datetime, timedelta
from database import FTTHDatabase
from extractors import DataExtractor
from exporters import ExcelExporter, PDFExporter
from config import MTN_COLORS
import pandas as pd

class FTTHApp:
    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("FTTH Extraction - MTN CI")
        self.root.geometry("1200x800")
        
        # Initialisation des composants
        self.db = FTTHDatabase()
        self.extractor = DataExtractor()
        self.excel_exporter = ExcelExporter()
        self.pdf_exporter = PDFExporter()
        
        # Variables
        self.current_data = {}
        self.logo_path = None
        self.last_export_path = os.getcwd()
        
        self.setup_ui()
    
    def setup_ui(self):
        """Configure l'interface utilisateur"""
        # Configuration du thème
        ctk.set_appearance_mode("Dark")
        
        # Frame principal
        main_frame = ctk.CTkFrame(self.root)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Titre
        title_label = ctk.CTkLabel(
            main_frame, 
            text="📊 FTTH EXTRACTION - MTN CÔTE D'IVOIRE",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=MTN_COLORS["primary"]
        )
        title_label.pack(pady=10)
        
        # Frame des boutons
        button_frame = ctk.CTkFrame(main_frame)
        button_frame.pack(fill="x", padx=10, pady=5)
        
        # Boutons principaux
        buttons_config = [
            ("📁 Charger fichier .txt", self.load_txt_file),
            ("🖼️ Importer logo", self.import_logo),
            ("📊 Export Excel", self.export_excel),
            ("📄 Export PDF", self.export_pdf),
            ("🔄 Export doublons", self.export_doublons),
            ("📦 Cumul matériel", self.show_cumul_materiel),
            ("📈 Rapport hebdo", lambda: self.generate_report("hebdo")),
            ("📅 Rapport mensuel", lambda: self.generate_report("mensuel")),
            ("💾 Import Excel", self.import_excel)
        ]
        
        for i, (text, command) in enumerate(buttons_config):
            btn = ctk.CTkButton(
                button_frame,
                text=text,
                command=command,
                fg_color=MTN_COLORS["primary"],
                hover_color=MTN_COLORS["accent"],
                text_color=MTN_COLORS["secondary"],
                font=ctk.CTkFont(weight="bold")
            )
            btn.grid(row=i//3, column=i%3, padx=5, pady=5, sticky="ew")
        
        # Configuration grid égale
        for i in range(3):
            button_frame.grid_columnconfigure(i, weight=1)
        
        # Zone d'affichage des résultats
        self.setup_results_display(main_frame)
    
    def setup_results_display(self, parent):
        """Configure la zone d'affichage des résultats"""
        notebook = ctk.CTkTabview(parent)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Onglets
        self.tabs = {
            "études": notebook.add("Études"),
            "installations": notebook.add("Installations"),
            "rendezvous": notebook.add("Rendez-vous"),
            "doublons": notebook.add("Doublons")
        }
        
        # Configuration des zones de texte
        self.text_widgets = {}
        
        for tab_name, tab_frame in self.tabs.items():
            text_widget = scrolledtext.ScrolledText(
                tab_frame,
                wrap=tk.WORD,
                font=("Consolas", 10),
                bg="#2b2b2b",
                fg="white",
                insertbackground="white"
            )
            text_widget.pack(fill="both", expand=True, padx=5, pady=5)
            self.text_widgets[tab_name] = text_widget
    
    def load_txt_file(self):
        """Charge et traite un fichier WhatsApp"""
        file_path = filedialog.askopenfilename(
            title="Sélectionner le fichier WhatsApp .txt",
            filetypes=[("Fichiers texte", "*.txt")]
        )
        
        if not file_path:
            return
        
        try:
            # Extraction des données
            self.current_data = self.extractor.extract_from_file(file_path)
            
            if not self.current_data:
                messagebox.showerror("Erreur", "Impossible d'extraire les données du fichier")
                return
            
            # Affichage des résultats
            self.display_results()
            
            # Sauvegarde en base
            self.save_to_database()
            
            messagebox.showinfo("Succès", 
                              f"Données extraites avec succès!\n"
                              f"Études: {len(self.current_data['etudes'])}\n"
                              f"Installations: {len(self.current_data['installations'])}\n"
                              f"RDV: {len(self.current_data['rendezvous'])}")
            
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement: {str(e)}")
    
    def display_results(self):
        """Affiche les résultats dans les onglets"""
        for data_type, text_widget in self.text_widgets.items():
            text_widget.delete(1.0, tk.END)
            
            if data_type in self.current_data:
                data_list = self.current_data[data_type]
                
                for item in data_list:
                    if data_type == "études":
                        text = f"Client: {item['nom_client']}\n"
                        text += f"TN: {item.get('tn', 'N/A')} | Numéro: {item.get('numero', 'N/A')}\n"
                        text += f"Localisation: {item.get('localisation', 'N/A')}\n"
                        text += f"Matériel: {item.get('materiel', 'N/A')}\n"
                        text += "-" * 50 + "\n"
                    
                    elif data_type == "installations":
                        text = f"Client: {item['nom_client']}\n"
                        text += f"Port: {item.get('port', 'N/A')} | TN: {item.get('tn', 'N/A')}\n"
                        text += f"Observation: {item.get('observation', 'N/A')}\n"
                        text += "-" * 50 + "\n"
                    
                    elif data_type == "rendezvous":
                        text = f"Client: {item['nom_client']}\n"
                        text += f"Date RDV: {item.get('date_rdv', 'N/A')}\n"
                        text += f"Message: {item['message_complet']}\n"
                        text += "-" * 50 + "\n"
                    
                    else:  # doublons
                        text = f"Client: {item['nom_client']}\n"
                        text += f"TN: {item.get('tn', 'N/A')}\n"
                        text += "-" * 50 + "\n"
                    
                    text_widget.insert(tk.END, text)
    
    def save_to_database(self):
        """Sauvegarde les données dans la base SQLite"""
        try:
            # Sauvegarde des études
            for etude in self.current_data['etudes']:
                self.db.insert_etude(etude)
            
            # Sauvegarde des installations
            for installation in self.current_data['installations']:
                self.db.insert_installation(installation)
            
            # Sauvegarde des RDV
            for rdv in self.current_data['rendezvous']:
                self.db.insert_rdv(rdv)
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur sauvegarde base: {str(e)}")
    
    def import_logo(self):
        """Importe un logo personnalisé"""
        file_path = filedialog.askopenfilename(
            title="Sélectionner le logo",
            filetypes=[("Images", "*.png *.jpg *.jpeg")]
        )
        
        if file_path:
            self.logo_path = file_path
            self.pdf_exporter.logo_path = file_path
            messagebox.showinfo("Succès", "Logo importé avec succès!")
    
    def export_excel(self):
        """Exporte les données en Excel"""
        if not self.current_data:
            messagebox.showwarning("Attention", "Aucune donnée à exporter")
            return
        
        output_path = filedialog.asksaveasfilename(
            title="Exporter en Excel",
            defaultextension=".xlsx",
            filetypes=[("Fichiers Excel", "*.xlsx")]
        )
        
        if output_path:
            try:
                # Conversion en DataFrames
                etudes_df = pd.DataFrame(self.current_data['etudes'])
                installations_df = pd.DataFrame(self.current_data['installations'])
                doublons_df = pd.DataFrame(self.current_data['doublons'])
                
                success = self.excel_exporter.export_etudes_installations(
                    etudes_df, installations_df, doublons_df, output_path
                )
                
                if success:
                    messagebox.showinfo("Succès", f"Export Excel réussi!\n{output_path}")
                    self.last_export_path = os.path.dirname(output_path)
                else:
                    messagebox.showerror("Erreur", "Échec de l'export Excel")
                    
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur export Excel: {str(e)}")
    
    def export_pdf(self):
        """Génère un rapport PDF"""
        if not self.current_data:
            messagebox.showwarning("Attention", "Aucune donnée à exporter")
            return
        
        output_path = filedialog.asksaveasfilename(
            title="Exporter en PDF",
            defaultextension=".pdf",
            filetypes=[("Fichiers PDF", "*.pdf")]
        )
        
        if output_path:
            try:
                # Conversion en DataFrames
                etudes_df = pd.DataFrame(self.current_data['etudes'])
                installations_df = pd.DataFrame(self.current_data['installations'])
                rdv_df = pd.DataFrame(self.current_data['rendezvous'])
                
                # Cumul matériel (simplifié)
                cumul_data = {"PTO": 10, "SMOOV": 5, "CABLE": 25}  # Exemple
                
                success = self.pdf_exporter.generate_report(
                    etudes_df, installations_df, rdv_df, cumul_data, output_path
                )
                
                if success:
                    messagebox.showinfo("Succès", f"Rapport PDF généré!\n{output_path}")
                else:
                    messagebox.showerror("Erreur", "Échec de la génération PDF")
                    
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur génération PDF: {str(e)}")
    
    def export_doublons(self):
        """Exporte les doublons"""
        if not self.current_data.get('doublons'):
            messagebox.showinfo("Info", "Aucun doublon détecté")
            return
        
        output_path = filedialog.asksaveasfilename(
            title="Exporter les doublons",
            defaultextension=".xlsx",
            filetypes=[("Fichiers Excel", "*.xlsx")]
        )
        
        if output_path:
            try:
                doublons_df = pd.DataFrame(self.current_data['doublons'])
                doublons_df.to_excel(output_path, index=False)
                messagebox.showinfo("Succès", f"Doublons exportés!\n{output_path}")
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur export doublons: {str(e)}")
    
    def show_cumul_materiel(self):
        """Affiche le cumul de matériel"""
        try:
            # Période par défaut (30 derniers jours)
            date_fin = datetime.now()
            date_debut = date_fin - timedelta(days=30)
            
            cumul_data = self.db.get_cumul_materiel(
                date_debut.strftime('%Y-%m-%d'),
                date_fin.strftime('%Y-%m-%d')
            )
            
            if cumul_data:
                cumul_text = "CUMUL MATÉRIEL (30 derniers jours):\n\n"
                for materiel, quantite in cumul_data.items():
                    cumul_text += f"• {materiel}: {quantite}\n"
                
                messagebox.showinfo("Cumul Matériel", cumul_text)
            else:
                messagebox.showinfo("Info", "Aucun matériel cumulé sur cette période")
                
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur calcul cumul: {str(e)}")
    
    def generate_report(self, periode_type):
        """Génère un rapport hebdomadaire ou mensuel"""
        try:
            if periode_type == "hebdo":
                date_debut = datetime.now() - timedelta(days=7)
                titre = "Hebdomadaire"
            else:
                date_debut = datetime.now() - timedelta(days=30)
                titre = "Mensuel"
            
            date_fin = datetime.now()
            
            # Récupération des données
            etudes_df = self.db.get_etudes(
                date_debut.strftime('%Y-%m-%d'),
                date_fin.strftime('%Y-%m-%d')
            )
            
            installations_df = self.db.get_installations(
                date_debut.strftime('%Y-%m-%d'),
                date_fin.strftime('%Y-%m-%d')
            )
            
            cumul_data = self.db.get_cumul_materiel(
                date_debut.strftime('%Y-%m-%d'),
                date_fin.strftime('%Y-%m-%d')
            )
            
            # Affichage du résumé
            resume = f"RAPPORT {titre.upper()}\n"
            resume += f"Période: {date_debut.strftime('%d/%m/%Y')} - {date_fin.strftime('%d/%m/%Y')}\n\n"
            resume += f"Études: {len(etudes_df)}\n"
            resume += f"Installations: {len(installations_df)}\n"
            
            if cumul_data:
                resume += "\nCumul Matériel:\n"
                for materiel, quantite in cumul_data.items():
                    resume += f"- {materiel}: {quantite}\n"
            
            messagebox.showinfo(f"Rapport {titre}", resume)
            
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur génération rapport: {str(e)}")
    
    def import_excel(self):
        """Importe des données depuis Excel"""
        messagebox.showinfo("Info", "Fonctionnalité d'import Excel en développement")
    
    def run(self):
        """Lance l'application"""
        self.root.mainloop()
