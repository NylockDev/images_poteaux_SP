# exporters.py
import pandas as pd
from fpdf import FPDF
import os
from datetime import datetime
from config import MTN_COLORS

class ExcelExporter:
    def __init__(self):
        self.style = MTN_COLORS
    
    def export_etudes_installations(self, etudes_df, installations_df, doublons_df, output_path):
        """Exporte les données en Excel avec thème MTN"""
        try:
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                # Feuille principale - Études
                if not etudes_df.empty:
                    etudes_df.to_excel(writer, sheet_name='Études', index=False)
                    worksheet = writer.sheets['Études']
                    self._apply_excel_style(worksheet, etudes_df)
                
                # Feuille installations
                if not installations_df.empty:
                    installations_df.to_excel(writer, sheet_name='Installations', index=False)
                    worksheet = writer.sheets['Installations']
                    self._apply_excel_style(worksheet, installations_df)
                
                # Feuille doublons
                if not doublons_df.empty:
                    doublons_df.to_excel(writer, sheet_name='Doublons', index=False)
                    worksheet = writer.sheets['Doublons']
                    self._apply_excel_style(worksheet, doublons_df)
            
            return True
        except Exception as e:
            print(f"Erreur export Excel: {e}")
            return False
    
    def export_cumul_materiel(self, cumul_data, output_path):
        """Exporte le cumul de matériel"""
        try:
            df = pd.DataFrame(list(cumul_data.items()), columns=['Matériel', 'Quantité'])
            df.to_excel(output_path, index=False)
            return True
        except Exception as e:
            print(f"Erreur export cumul: {e}")
            return False
    
    def _apply_excel_style(self, worksheet, df):
        """Applique le style MTN aux feuilles Excel"""
        from openpyxl.styles import PatternFill, Font
        
        # En-tête jaune MTN
        header_fill = PatternFill(start_color=MTN_COLORS['primary'], 
                                end_color=MTN_COLORS['primary'], 
                                fill_type='solid')
        header_font = Font(color=MTN_COLORS['secondary'], bold=True)
        
        for col in range(1, len(df.columns) + 1):
            cell = worksheet.cell(1, col)
            cell.fill = header_fill
            cell.font = header_font

class PDFExporter:
    def __init__(self, logo_path=None):
        self.logo_path = logo_path
    
    def generate_report(self, etudes_df, installations_df, rdv_df, cumul_data, output_path, periode="Mensuel"):
        """Génère un rapport PDF complet"""
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        
        # Page de garde
        self._add_cover_page(pdf, periode)
        
        # Résumé
        self._add_summary_section(pdf, etudes_df, installations_df, rdv_df, cumul_data)
        
        # Détails études
        if not etudes_df.empty:
            self._add_etudes_section(pdf, etudes_df)
        
        # Détails installations
        if not installations_df.empty:
            self._add_installations_section(pdf, installations_df)
        
        # RDV
        if not rdv_df.empty:
            self._add_rdv_section(pdf, rdv_df)
        
        pdf.output(output_path)
        return True
    
    def _add_cover_page(self, pdf, periode):
        """Ajoute la page de garde"""
        pdf.add_page()
        
        # Logo
        if self.logo_path and os.path.exists(self.logo_path):
            pdf.image(self.logo_path, x=80, y=40, w=50)
        
        # Titre
        pdf.set_font('Arial', 'B', 24)
        pdf.set_text_color(255, 204, 0)  # Jaune MTN
        pdf.cell(0, 80, 'RAPPORT FTTH', ln=True, align='C')
        
        # Sous-titre
        pdf.set_font('Arial', 'I', 16)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 10, f'Période: {periode}', ln=True, align='C')
        pdf.cell(0, 10, f'Date: {datetime.now().strftime("%d/%m/%Y")}', ln=True, align='C')
    
    def _add_summary_section(self, pdf, etudes_df, installations_df, rdv_df, cumul_data):
        """Ajoute la section résumé"""
        pdf.add_page()
        pdf.set_font('Arial', 'B', 16)
        pdf.set_text_color(255, 204, 0)
        pdf.cell(0, 10, 'RÉSUMÉ', ln=True)
        
        pdf.set_font('Arial', '', 12)
        pdf.set_text_color(0, 0, 0)
        
        # Statistiques
        stats = [
            f"Études réalisées: {len(etudes_df)}",
            f"Installations effectuées: {len(installations_df)}",
            f"Rendez-vous planifiés: {len(rdv_df)}",
            f"Période: {datetime.now().strftime('%B %Y')}"
        ]
        
        for stat in stats:
            pdf.cell(0, 8, stat, ln=True)
        
        # Cumul matériel
        if cumul_data:
            pdf.ln(5)
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 8, 'CUMUL MATÉRIEL:', ln=True)
            pdf.set_font('Arial', '', 10)
            
            for materiel, quantite in cumul_data.items():
                pdf.cell(0, 6, f"- {materiel}: {quantite}", ln=True)
    
    def _add_etudes_section(self, pdf, etudes_df):
        """Ajoute la section études"""
        pdf.add_page()
        pdf.set_font('Arial', 'B', 16)
        pdf.set_text_color(255, 204, 0)
        pdf.cell(0, 10, 'ÉTUDES FTTH', ln=True)
        
        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(0, 0, 0)
        
        for idx, row in etudes_df.iterrows():
            pdf.multi_cell(0, 6, f"{idx+1}. {row['nom_client']} - TN: {row.get('tn', 'N/A')} - Localisation: {row.get('localisation', 'N/A')}")
            pdf.ln(2)
    
    def _add_installations_section(self, pdf, installations_df):
        """Ajoute la section installations"""
        pdf.add_page()
        pdf.set_font('Arial', 'B', 16)
        pdf.set_text_color(255, 204, 0)
        pdf.cell(0, 10, 'INSTALLATIONS', ln=True)
        
        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(0, 0, 0)
        
        for idx, row in installations_df.iterrows():
            pdf.multi_cell(0, 6, f"{idx+1}. {row['nom_client']} - Port: {row.get('port', 'N/A')} - Observation: {row.get('observation', 'N/A')}")
            pdf.ln(2)
    
    def _add_rdv_section(self, pdf, rdv_df):
        """Ajoute la section rendez-vous"""
        pdf.add_page()
        pdf.set_font('Arial', 'B', 16)
        pdf.set_text_color(255, 204, 0)
        pdf.cell(0, 10, 'RENDEZ-VOUS', ln=True)
        
        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(0, 0, 0)
        
        for idx, row in rdv_df.iterrows():
            pdf.multi_cell(0, 6, f"{idx+1}. {row['nom_client']} - Date: {row.get('date_rdv', 'N/A')}")
            pdf.multi_cell(0, 6, f"   Message: {row['message_complet'][:100]}...")
            pdf.ln(2)
